## Generated Story 2722137462158439606
* greeting
    - utter_greet
* get_horoscope{"horoscope_sign": "Virgo"}
    - slot{"horoscope_sign": "Virgo"}
    - get_todays_horoscope
    - slot{"horoscope_sign": "Virgo"}
    
## story
* greeting
  - utter_greet
* get_mathfact
  - get_random_mathfact
  
## story
* greeting
  - utter_greet
* leave
  - utter_ask_why_leave
* tell_why_leave
  - utter_soon

## Generated Story -4465653751702725354
* greeting
    - utter_greet
* get_horoscope
    - utter_ask_horoscope_sign
* get_horoscope{"horoscope_sign": "Capricorn"}
    - slot{"horoscope_sign": "Capricorn"}
    - get_todays_horoscope
    - slot{"horoscope_sign": "Capricorn"}
    - utter_subscribe
* get_mathfact
    - get_random_mathfact
* get_mathfact
    - get_random_mathfact
    
## story
* greeting
  - utter_greet
* ask_name
  - utter_name

## story
* greeting
  - utter_greet
* ask_name
  - utter_name
* ask_quality
  - utter_quality

## Generated Story -954772278679157831
* greeting
    - utter_greet
* get_mathfact
    - get_random_mathfact
* leave
    - utter_leave

## Generated Story -2353653055119758028
* greeting
    - utter_greet
* ask_name
    - utter_name
* ask_quality
    - utter_quality
* get_horoscope
    - utter_ask_horoscope_sign
* get_horoscope{"horoscope_sign": "Virgo"}
    - slot{"horoscope_sign": "Virgo"}
    - get_todays_horoscope
    - slot{"horoscope_sign": "Virgo"}

## Generated Story -4084479084374116095
* greeting
    - utter_greet
* get_horoscope
    - utter_ask_horoscope_sign
* get_horoscope{"horoscope_sign": "Aries"}
    - slot{"horoscope_sign": "Aries"}
    - get_todays_horoscope
    - slot{"horoscope_sign": "Aries"}
* get_horoscope
    - utter_ask_horoscope_sign
* get_horoscope{"horoscope_sign": "Taurus"}
    - slot{"horoscope_sign": "Taurus"}
    - get_todays_horoscope
    - slot{"horoscope_sign": "Taurus"}
* get_horoscope
    - utter_ask_horoscope_sign
* get_horoscope{"horoscope_sign": "Gemini"}
    - slot{"horoscope_sign": "Gemini"}
    - get_todays_horoscope
    - slot{"horoscope_sign": "Gemini"}
* get_horoscope
    - utter_ask_horoscope_sign
* get_horoscope{"horoscope_sign": "Cancer"}
    - slot{"horoscope_sign": "Cancer"}
    - get_todays_horoscope
    - slot{"horoscope_sign": "Cancer"}

## Generated Story -6667605775657441586
* greeting
    - utter_greet
* ask_name
    - utter_name
* ask_quality
    - utter_quality
* get_horoscope
    - utter_ask_horoscope_sign
* get_horoscope{"horoscope_sign": "Aries"}
    - slot{"horoscope_sign": "Aries"}
    - get_todays_horoscope
    - slot{"horoscope_sign": "Aries"}
* leave
    - utter_leave

## Generated Story 9083376162807091610
* greeting
    - utter_greet
* ask_quality
    - utter_quality
* get_horoscope
    - utter_ask_horoscope_sign
* get_horoscope{"horoscope_sign": "Aries"}
    - slot{"horoscope_sign": "Aries"}
    - get_todays_horoscope
    - slot{"horoscope_sign": "Aries"}
* leave
    - utter_leave

## Generated Story -6604085367020107038
* greeting
    - utter_greet
* leave
    - utter_leave

## Generated Story 6127725378807495877
* greeting
    - utter_greet
* ask_quality
    - utter_quality
* ask_name
    - utter_name
* get_horoscope
    - utter_ask_horoscope_sign
* get_horoscope{"horoscope_sign": "Capricorn"}
    - slot{"horoscope_sign": "Capricorn"}
    - get_todays_horoscope
    - slot{"horoscope_sign": "Capricorn"}
* get_horoscope
    - utter_ask_horoscope_sign
* get_horoscope{"horoscope_sign": "Aries"}
    - slot{"horoscope_sign": "Aries"}
    - get_todays_horoscope
    - slot{"horoscope_sign": "Aries"}
* get_horoscope
    - utter_ask_horoscope_sign
* get_horoscope{"horoscope_sign": "Virgo"}
    - slot{"horoscope_sign": "Virgo"}
    - get_todays_horoscope
    - slot{"horoscope_sign": "Virgo"}
* get_horoscope
    - utter_ask_horoscope_sign
* get_horoscope{"horoscope_sign": "Cancer"}
    - slot{"horoscope_sign": "Cancer"}
    - get_todays_horoscope
    - slot{"horoscope_sign": "Cancer"}
* get_mathfact
    - get_random_mathfact
* get_mathfact
    - get_random_mathfact
* leave
    - utter_leave

## Generated Story 5110298434630042348
* greeting
    - utter_greet
* get_horoscope
    - utter_ask_horoscope_sign
* get_horoscope{"horoscope_sign": "Virgo"}
    - slot{"horoscope_sign": "Virgo"}
    - get_todays_horoscope
    - slot{"horoscope_sign": "Virgo"}
* leave
    - utter_leave

## Generated Story -811866581418238653
* greeting
    - utter_greet
* get_horoscope
    - utter_ask_horoscope_sign
* get_horoscope{"horoscope_sign": "Aries"}
    - slot{"horoscope_sign": "Aries"}
    - get_todays_horoscope
    - slot{"horoscope_sign": "Aries"}
* get_horoscope
    - utter_ask_horoscope_sign
* get_horoscope{"horoscope_sign": "Taurus"}
    - slot{"horoscope_sign": "Taurus"}
    - get_todays_horoscope
    - slot{"horoscope_sign": "Taurus"}
* get_horoscope
    - utter_ask_horoscope_sign
* get_horoscope{"horoscope_sign": "Gemini"}
    - slot{"horoscope_sign": "Gemini"}
    - get_todays_horoscope
    - slot{"horoscope_sign": "Gemini"}
* get_horoscope
    - utter_ask_horoscope_sign
* get_horoscope{"horoscope_sign": "Cancer"}
    - slot{"horoscope_sign": "Cancer"}
    - get_todays_horoscope
    - slot{"horoscope_sign": "Cancer"}
* get_horoscope
    - utter_ask_horoscope_sign
* get_horoscope{"horoscope_sign": "Leo"}
    - slot{"horoscope_sign": "Leo"}
    - get_todays_horoscope
    - slot{"horoscope_sign": "Leo"}
* get_horoscope
    - utter_ask_horoscope_sign
* get_horoscope{"horoscope_sign": "Virgo"}
    - slot{"horoscope_sign": "Virgo"}
    - get_todays_horoscope
    - slot{"horoscope_sign": "Virgo"}
* get_horoscope
    - utter_ask_horoscope_sign
* get_horoscope{"horoscope_sign": "Libra"}
    - slot{"horoscope_sign": "Libra"}
    - get_todays_horoscope
    - slot{"horoscope_sign": "Libra"}
* get_horoscope
    - utter_ask_horoscope_sign
* get_horoscope{"horoscope_sign": "Scorpio"}
    - slot{"horoscope_sign": "Scorpio"}
    - get_todays_horoscope
    - slot{"horoscope_sign": "Scorpio"}
* get_horoscope
    - utter_ask_horoscope_sign
* get_horoscope{"horoscope_sign": "Sagittarius"}
    - slot{"horoscope_sign": "Sagittarius"}
    - get_todays_horoscope
    - slot{"horoscope_sign": "Sagittarius"}
* get_horoscope
    - utter_ask_horoscope_sign
* get_horoscope{"horoscope_sign": "Capricorn"}
    - slot{"horoscope_sign": "Capricorn"}
    - get_todays_horoscope
    - slot{"horoscope_sign": "Capricorn"}
* get_horoscope
    - utter_ask_horoscope_sign
* get_horoscope{"horoscope_sign": "Aquarius"}
    - slot{"horoscope_sign": "Aquarius"}
    - get_todays_horoscope
    - slot{"horoscope_sign": "Aquarius"}
* get_horoscope
    - utter_ask_horoscope_sign
* get_horoscope{"horoscope_sign": "Pisces"}
    - slot{"horoscope_sign": "Pisces"}
    - get_todays_horoscope
    - slot{"horoscope_sign": "Pisces"}

## Generated Story 8781641220965243906
* greeting
    - utter_greet
* get_horoscope
    - utter_ask_horoscope_sign
* get_horoscope{"horoscope_sign": "Aries"}
    - slot{"horoscope_sign": "Aries"}
    - get_todays_horoscope
    - slot{"horoscope_sign": "Aries"}
* get_horoscope
    - utter_ask_horoscope_sign
* get_horoscope{"horoscope_sign": "Taurus"}
    - slot{"horoscope_sign": "Taurus"}
    - get_todays_horoscope
    - slot{"horoscope_sign": "Taurus"}
* get_horoscope
    - utter_ask_horoscope_sign
* get_horoscope{"horoscope_sign": "Gemini"}
    - slot{"horoscope_sign": "Gemini"}
    - get_todays_horoscope
    - slot{"horoscope_sign": "Gemini"}
* get_horoscope
    - utter_ask_horoscope_sign
* get_horoscope{"horoscope_sign": "Cancer"}
    - slot{"horoscope_sign": "Cancer"}
    - get_todays_horoscope
    - slot{"horoscope_sign": "Cancer"}
* get_horoscope
    - utter_ask_horoscope_sign
* get_horoscope{"horoscope_sign": "Leo"}
    - slot{"horoscope_sign": "Leo"}
    - get_todays_horoscope
    - slot{"horoscope_sign": "Leo"}
* get_horoscope
    - utter_ask_horoscope_sign
* get_horoscope
    - utter_ask_horoscope_sign
* get_horoscope{"horoscope_sign": "Virgo"}
    - slot{"horoscope_sign": "Virgo"}
    - get_todays_horoscope
    - slot{"horoscope_sign": "Virgo"}
* get_horoscope
    - utter_ask_horoscope_sign
* get_horoscope{"horoscope_sign": "Libra"}
    - slot{"horoscope_sign": "Libra"}
    - get_todays_horoscope
    - slot{"horoscope_sign": "Libra"}
* get_horoscope
    - utter_ask_horoscope_sign
* get_horoscope{"horoscope_sign": "Scorpio"}
    - slot{"horoscope_sign": "Scorpio"}
    - get_todays_horoscope
    - slot{"horoscope_sign": "Scorpio"}
* get_horoscope
    - utter_ask_horoscope_sign
* get_horoscope{"horoscope_sign": "Sagittarius"}
    - slot{"horoscope_sign": "Sagittarius"}
    - get_todays_horoscope
    - slot{"horoscope_sign": "Sagittarius"}
* get_horoscope
    - utter_ask_horoscope_sign
* get_horoscope{"horoscope_sign": "Capricorn"}
    - slot{"horoscope_sign": "Capricorn"}
    - get_todays_horoscope
    - slot{"horoscope_sign": "Capricorn"}
* get_horoscope
    - utter_ask_horoscope_sign
* get_horoscope{"horoscope_sign": "Aquarius"}
    - slot{"horoscope_sign": "Aquarius"}
    - get_todays_horoscope
    - slot{"horoscope_sign": "Aquarius"}
* get_horoscope
    - utter_ask_horoscope_sign
* get_horoscope{"horoscope_sign": "Pisces"}
    - slot{"horoscope_sign": "Pisces"}
    - get_todays_horoscope
    - slot{"horoscope_sign": "Pisces"}
    
## story
* greeting
  - utter_greet
* get_logo
  - utter_logo
* leave
  - utter_leave
  


## Generated Story 2634511524467895376
* greeting
    - utter_greet
* get_logo{"university": "BU"}
    - utter_logo
* leave
    - utter_leave
